const jwt_KEY = "abasery";


module.exports = { jwt_KEY }